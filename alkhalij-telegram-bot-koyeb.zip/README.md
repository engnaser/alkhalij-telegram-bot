# بوت الخليج تيليكوم على Koyeb

هذه نسخة Webhook مناسبة للتشغيل المجاني على Koyeb كـ Web Service.

## الملفات
- app.py
- requirements.txt
- Procfile

## متغيرات البيئة المطلوبة في Koyeb
- BOT_TOKEN = توكن البوت من BotFather
- WEBHOOK_URL = رابط تطبيق Koyeb بعد النشر، مثال:
  https://alkhalij-telegram-bot-yourname.koyeb.app

## متغيرات اختيارية
- APP_LINK
- OTHER_APPS_LINK
- ARCHIVE_LINK
- PHONE_1
- PHONE_2
- WHATSAPP_LINK

## Start Command
gunicorn app:app --bind 0.0.0.0:$PORT
