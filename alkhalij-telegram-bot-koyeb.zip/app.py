import os
import telebot
from telebot import types
from flask import Flask, request

BOT_TOKEN = os.getenv("BOT_TOKEN")
WEBHOOK_URL = os.getenv("WEBHOOK_URL", "")

APP_LINK = os.getenv("APP_LINK", "ضع_رابط_التطبيق_هنا")
OTHER_APPS_LINK = os.getenv("OTHER_APPS_LINK", "ضع_رابط_تطبيقاتنا_الأخرى_هنا")
ARCHIVE_LINK = os.getenv("ARCHIVE_LINK", "ضع_رابط_الأرشيف_هنا")
PHONE_1 = os.getenv("PHONE_1", "775608601")
PHONE_2 = os.getenv("PHONE_2", "781635755")
WHATSAPP_LINK = os.getenv("WHATSAPP_LINK", "https://wa.me/967775608601")

if not BOT_TOKEN:
    raise RuntimeError("BOT_TOKEN is missing")

bot = telebot.TeleBot(BOT_TOKEN, parse_mode="HTML")
app = Flask(__name__)


def main_menu():
    markup = types.InlineKeyboardMarkup(row_width=1)
    markup.add(
        types.InlineKeyboardButton("📞 خدمة العملاء", callback_data="support"),
        types.InlineKeyboardButton("📱 حمل التطبيق وافتح حساب", callback_data="open_account"),
        types.InlineKeyboardButton("💳 تغذية الحساب", callback_data="wallet_topup"),
        types.InlineKeyboardButton("🔐 نسيت كلمة السر", callback_data="forgot_password"),
        types.InlineKeyboardButton("🗂 الدخول إلى الأرشيف", callback_data="archive"),
        types.InlineKeyboardButton("📲 تحميل تطبيقاتنا الأخرى", callback_data="other_apps"),
        types.InlineKeyboardButton("⭐ خدمات الخليج تيليكوم", callback_data="services"),
    )
    return markup


def back_menu():
    markup = types.InlineKeyboardMarkup()
    markup.add(types.InlineKeyboardButton("🔙 رجوع للقائمة الرئيسية", callback_data="back"))
    return markup


@bot.message_handler(commands=["start", "menu"])
def send_welcome(message):
    text = (
        "مرحباً بك في بوت الخليج تيليكوم 👋\n\n"
        "اختر الخدمة المطلوبة من القائمة التالية:"
    )
    bot.send_message(message.chat.id, text, reply_markup=main_menu())


@bot.callback_query_handler(func=lambda call: True)
def callback_handler(call):
    data = call.data

    if data == "back":
        bot.edit_message_text(
            "اختر الخدمة المطلوبة من القائمة التالية:",
            call.message.chat.id,
            call.message.message_id,
            reply_markup=main_menu()
        )
        return

    if data == "support":
        text = (
            "📞 <b>خدمة العملاء</b>\n\n"
            f"للتواصل والاستفسار:\n"
            f"📱 اتصال: {PHONE_1} - {PHONE_2}\n"
            f"💬 واتساب: {WHATSAPP_LINK}\n\n"
            "يسعدنا خدمتك في الخليج تيليكوم."
        )

    elif data == "open_account":
        text = (
            "📱 <b>حمل التطبيق وافتح حساب</b>\n\n"
            "يمكنك تحميل تطبيق الخليج تيليكوم وفتح حساب جديد بسهولة.\n\n"
            f"🔗 رابط التحميل:\n{APP_LINK}\n\n"
            "بعد التحميل افتح التطبيق واتبع خطوات إنشاء الحساب."
        )

    elif data == "wallet_topup":
        text = (
            "💳 <b>تغذية الحساب</b>\n\n"
            "لتغذية حسابك في تطبيق الخليج تيليكوم:\n"
            "1- تواصل مع خدمة العملاء.\n"
            "2- أرسل رقم حسابك أو رقم جوالك.\n"
            "3- سيتم تزويدك بطريقة التغذية المناسبة.\n\n"
            f"📞 للتواصل: {PHONE_1} - {PHONE_2}"
        )

    elif data == "forgot_password":
        text = (
            "🔐 <b>نسيت كلمة السر</b>\n\n"
            "لاستعادة كلمة السر:\n"
            "1- افتح تطبيق الخليج تيليكوم.\n"
            "2- اضغط على نسيت كلمة السر.\n"
            "3- أدخل رقم الهاتف المرتبط بالحساب.\n"
            "4- اتبع التعليمات.\n\n"
            "إذا واجهت مشكلة، تواصل مع خدمة العملاء."
        )

    elif data == "archive":
        text = (
            "🗂 <b>الدخول إلى الأرشيف</b>\n\n"
            "يمكنك الدخول إلى الأرشيف من الرابط التالي:\n"
            f"{ARCHIVE_LINK}\n\n"
            "أو من داخل التطبيق عبر قسم الأرشيف / العمليات."
        )

    elif data == "other_apps":
        text = (
            "📲 <b>تحميل تطبيقاتنا الأخرى</b>\n\n"
            "يمكنك تحميل تطبيقات الخليج تيليكوم الأخرى من الرابط التالي:\n"
            f"{OTHER_APPS_LINK}"
        )

    elif data == "services":
        text = (
            "⭐ <b>خدمات الخليج تيليكوم</b>\n\n"
            "الخدمات المتوفرة:\n"
            "✅ شحن الرصيد والباقات\n"
            "✅ تسديد فواتير الإنترنت والهاتف\n"
            "✅ خدمات يمن موبايل\n"
            "✅ خدمات YOU\n"
            "✅ خدمات سبأفون\n"
            "✅ خدمات واي\n"
            "✅ يمن فورجي ويمن نت وعدن نت\n"
            "✅ شحن الألعاب والبطاقات الإلكترونية\n\n"
            "اختر الخدمة المطلوبة وتواصل معنا لتنفيذها."
        )
    else:
        text = "اختر خدمة من القائمة."

    bot.answer_callback_query(call.id)
    bot.edit_message_text(text, call.message.chat.id, call.message.message_id, reply_markup=back_menu())


@app.route("/", methods=["GET"])
def home():
    return "Al-Khalij Telegram Bot is running ✅", 200


@app.route("/webhook", methods=["POST"])
def webhook():
    update = telebot.types.Update.de_json(request.get_data().decode("utf-8"))
    bot.process_new_updates([update])
    return "ok", 200


if WEBHOOK_URL:
    bot.remove_webhook()
    bot.set_webhook(url=WEBHOOK_URL.rstrip("/") + "/webhook")
